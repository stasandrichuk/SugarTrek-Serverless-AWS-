def hello(event, context):
    return { "message": "Go Serverless v1.0! Your function executed successfully!", "event": event }
